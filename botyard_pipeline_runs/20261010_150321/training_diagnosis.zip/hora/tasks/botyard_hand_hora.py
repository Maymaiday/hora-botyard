# --------------------------------------------------------
# In-Hand Object Rotation via Rapid Motor Adaptation
# https://arxiv.org/abs/2210.04887
# Copyright (c) 2022 Haozhi Qi
# Licensed under The MIT License [see LICENSE for details]
# --------------------------------------------------------

import os
import torch
import numpy as np
from isaacgym import gymtorch
from isaacgym import gymapi
from isaacgym.torch_utils import to_torch, unscale, quat_apply, tensor_clamp, torch_rand_float, quat_conjugate, quat_mul
from glob import glob
from hora.utils.misc import tprint
from .base.vec_task import VecTask
from .botyard_grasp_cache import read_cache
from .botyard_pose_contract import apply_collision_masks
from .botyard_training_contract import state_offsets


class BotyardHandHoraVecTask(VecTask):
    def __init__(self, config, sim_device, graphics_device_id, headless):
        self.config = config
        mode=config['env'].get('trainingMode','constrained')
        if mode not in ('constrained','hora_baseline'):raise ValueError('Unknown trainingMode: '+str(mode))
        self.hora_baseline=mode=='hora_baseline'
        if self.hora_baseline and config['env']['genGrasps']:raise ValueError('hora_baseline is a training mode, not grasp generation')
        if self.hora_baseline:
            print('[阶段] HORA 基线：读取已有缓存，五项原始奖励，URDF 动作边界，掉落/超时重置',flush=True)
        if config['sim']['use_gpu_pipeline']:
            raise ValueError('Use pipeline=cpu for point-contact inspection; sim_device=cuda:0 supports GPU PhysX')
        if sim_device != 'cpu' and not (sim_device.startswith('cuda:') and sim_device[5:].isdigit()):
            raise ValueError('sim_device must be cpu or cuda:<index>')
        gpu_physics=sim_device.startswith('cuda:')
        if bool(config['sim']['physx']['use_gpu']) != gpu_physics:
            raise ValueError('sim_device and sim.physx.use_gpu disagree; refusing a silent backend fallback')
        self.simulation_backend=dict(simDevice=sim_device,physics='gpu' if gpu_physics else 'cpu',
            tensorPipeline='cpu',controllerFeedback='every_physics_step')
        print('[BACKEND]',self.simulation_backend,flush=True)
        self.cpu_feedback_each_substep = True
        # before calling init in VecTask, need to do
        # 1. setup randomization
        self._setup_domain_rand_config(config['env']['randomization'])
        # 2. setup privileged information
        self._setup_priv_option_config(config['env']['privInfo'])
        # 3. setup object assets
        self._setup_object_info(config['env']['object'])
        # 4. setup reward
        self._setup_reward_config(config['env']['reward'])
        self.base_obj_scale = config['env']['baseObjScale']
        self.save_init_pose = config['env']['genGrasps']
        import json
        count=int(config['env']['numEnvs'])
        scales=[float(self.base_obj_scale)] if self.save_init_pose else self.randomize_scale_list
        if count<1 or (not self.save_init_pose and count%len(scales)):
            raise ValueError('Training numEnvs must be a positive multiple of the number of scales')
        self.env_scales_np=np.array([scales[i%len(scales)] for i in range(count)])
        self.scale_seeds={}
        for scale in scales:
            seed_path=config['env']['botyard']['scaleSeedFiles'][str(float(scale))]
            with open(seed_path) as fh:self.scale_seeds[str(float(scale))]=json.load(fh)['candidates'][0]
            if not np.isclose(self.scale_seeds[str(float(scale))]['objectScale'],scale):raise ValueError('Scale seed mismatch')
        self.aggregate_mode = self.config['env']['aggregateMode']
        self.up_axis = 'z'
        self.reset_z_threshold = self.config['env']['reset_height_threshold']
        self.grasp_cache_name = self.config['env']['grasp_cache_name']
        self.evaluate = self.config['on_evaluation']
        self.priv_info_dict = {
            'obj_position': (0, 3),
            'obj_scale': (3, 4),
            'obj_mass': (4, 5),
            'obj_friction': (5, 6),
            'obj_com': (6, 9),
        }

        super().__init__(config, sim_device, graphics_device_id, headless)

        if self.num_actions != self.num_policy_dofs:
            raise RuntimeError(
                f'BotYard policy must remain 16-D: config numActions={self.num_actions}, '
                f'policy DOFs={self.num_policy_dofs}'
            )

        self.debug_viz = self.config['env']['enableDebugVis']
        self.max_episode_length = self.config['env']['episodeLength']
        self.dt = self.sim_params.dt

        if self.viewer:
            c=config['env']['botyard']['objectPosition']
            cam_pos = gymapi.Vec3(c[0]+.25,c[1]-.38,c[2]+.18)
            cam_target = gymapi.Vec3(*map(float,c))
            self.gym.viewer_camera_look_at(self.viewer, None, cam_pos, cam_target)

        # get gym GPU state tensors
        actor_root_state_tensor = self.gym.acquire_actor_root_state_tensor(self.sim)
        dof_state_tensor = self.gym.acquire_dof_state_tensor(self.sim)
        rigid_body_tensor = self.gym.acquire_rigid_body_state_tensor(self.sim)
        net_contact_forces = self.gym.acquire_net_contact_force_tensor(self.sim)

        # create some wrapper tensors for different slices
        self.allegro_hand_default_dof_pos = torch.zeros(self.num_allegro_hand_dofs, dtype=torch.float, device=self.device)
        self.dof_state = gymtorch.wrap_tensor(dof_state_tensor)
        self.contact_forces = gymtorch.wrap_tensor(net_contact_forces).view(self.num_envs, -1, 3)
        self.allegro_hand_dof_state = self.dof_state.view(self.num_envs, -1, 2)[:, :self.num_allegro_hand_dofs]
        self.allegro_hand_dof_pos = self.allegro_hand_dof_state[..., 0]
        self.allegro_hand_dof_vel = self.allegro_hand_dof_state[..., 1]

        self.rigid_body_states = gymtorch.wrap_tensor(rigid_body_tensor).view(self.num_envs, -1, 13)
        self.num_bodies = self.rigid_body_states.shape[1]

        self.root_state_tensor = gymtorch.wrap_tensor(actor_root_state_tensor).view(-1, 13)

        self._refresh_gym()
        origins=[self.gym.get_env_origin(env) for env in self.envs]
        self.env_origins=to_torch([[v.x,v.y,v.z] for v in origins],device=self.device)
        # Identify the tensor frame only after an actual physics step. Never
        # infer it from an unstepped object buffer with contact corrections.
        seed_q=to_torch([self.scale_seeds[str(float(scale))]['actualQ20'] for scale in self.env_scales_np],device=self.device)
        self.allegro_hand_dof_pos[:]=seed_q;self.allegro_hand_dof_vel[:]=0
        hi=self.hand_indices.to(torch.int32)
        self.gym.set_dof_state_tensor_indexed(self.sim,gymtorch.unwrap_tensor(self.dof_state),gymtorch.unwrap_tensor(hi),len(hi))
        self.gym.simulate(self.sim);self.gym.fetch_results(self.sim,True);self._refresh_gym()
        configured=np.array([self.scale_seeds[str(float(scale))]['handRoot7'] for scale in self.env_scales_np])
        measured=self.root_state_tensor[self.hand_indices,:7].cpu().numpy()
        offsets,frame_name=state_offsets(measured[:,:3],configured[:,:3],self.env_origins.cpu().numpy())
        if np.any(np.abs(np.sum(measured[:,3:]*configured[:,3:],axis=1))<.99999):raise RuntimeError('Fixed hand root orientation was changed')
        self.state_offsets=to_torch(offsets,device=self.device)
        self.env_scales=to_torch(self.env_scales_np,device=self.device)
        self.fixed_hand_root_local=to_torch(configured[0],device=self.device)
        print('[COORDINATES] post-physics fixed roots verified:',frame_name,'envs',self.num_envs,flush=True)
        print('[ROOTS]',{k:v['handRoot7'] for k,v in self.scale_seeds.items()},flush=True)

        self.num_dofs = self.gym.get_sim_dof_count(self.sim) // self.num_envs

        self.prev_targets = torch.zeros((self.num_envs, self.num_dofs), dtype=torch.float, device=self.device)
        self.cur_targets = torch.zeros((self.num_envs, self.num_dofs), dtype=torch.float, device=self.device)
        
        self.prev_policy_targets = torch.zeros(
            (self.num_envs, self.num_policy_dofs),
            dtype=torch.float,
            device=self.device
        )

        self.cur_policy_targets = torch.zeros(
            (self.num_envs, self.num_policy_dofs),
            dtype=torch.float,
            device=self.device
        )

        self.policy_dof_lower_limits = \
            self.allegro_hand_dof_lower_limits[self.policy_dof_indices]

        self.policy_dof_upper_limits = \
            self.allegro_hand_dof_upper_limits[self.policy_dof_indices]

        # ------------------------------------------------------------------
        # Canonical grasp target used when restoring grasp-cache states.
        # NOTE: this block must come after policy DOF limits are initialized.
        #
        # Important:
        #   the cache stores the ACTUAL 20-D hand configuration reached after
        #   the grasp has settled, but the grasp is maintained by a distinct
        #   16-D policy target.  Resetting target := cached actual q removes
        #   the PD holding force and causes most grasps to drop.
        #
        # We therefore restore:
        #   actual q      <- cache
        #   policy target <- the sampled cache row's policyTargets
        #   full target   <- expand_policy_targets(sampled policyTargets)
        # ------------------------------------------------------------------
        canonical = self.config['env'].get('canonicalPolicyPose', None)
        if canonical is None:
            raise KeyError(
                'Missing env.canonicalPolicyPose in BotyardHandHora config. '
                'A 16-D canonical grasp target is required for fixed-wrist cache reset.'
            )
        if len(canonical) != self.num_policy_dofs:
            raise ValueError(
                f'canonicalPolicyPose must have {self.num_policy_dofs} values, '
                f'got {len(canonical)}.'
            )

        self.canonical_policy_pose = to_torch(
            canonical,
            dtype=torch.float,
            device=self.device,
        )
        self.canonical_policy_pose = tensor_clamp(
            self.canonical_policy_pose,
            self.policy_dof_lower_limits,
            self.policy_dof_upper_limits,
        )

        print(
            'BotYard canonical policy target:',
            [round(float(x), 6) for x in self.canonical_policy_pose.tolist()]
        )

      
        
        
        # object apply random forces parameters
        self.force_scale = self.config['env'].get('forceScale', 0.0)
        self.random_force_prob_scalar = self.config['env'].get('randomForceProbScalar', 0.0)
        self.force_decay = self.config['env'].get('forceDecay', 0.99)
        self.force_decay_interval = self.config['env'].get('forceDecayInterval', 0.08)
        self.force_decay = to_torch(self.force_decay, dtype=torch.float, device=self.device)
        self.rb_forces = torch.zeros((self.num_envs, self.num_bodies, 3), dtype=torch.float, device=self.device)

        self.cached_policy_targets={}
        if not self.save_init_pose:
            if not (self.randomize_scale and self.scale_list_init):
                raise ValueError('Training from grasp caches requires randomizeScale=True and scaleListInit=True')
            self.saved_grasping_states={}
            tag=str(self.config['env'].get('graspCacheCountTag','50k'))
            for scale in self.randomize_scale_list:
                path=f'cache/{self.grasp_cache_name}_grasp_{tag}_s{str(scale).replace(".", "")}.npy'
                states,targets,metadata=read_cache(path,self.sim_dof_names,scale,
                    self.scale_seeds[str(float(scale))]['handRoot7'],self.config['env']['object']['assetFile'],
                    self.config['env']['asset']['handAsset'])
                if not metadata.get('complete',False):raise ValueError('Cannot train from incomplete cache')
                controller=self.config['env']['controller']
                if metadata.get('torqueControl')!=bool(self.torque_control):raise ValueError('Cache/controller torque mode mismatch')
                if metadata.get('validationVersion')!='five_side_pose_motion_v3':raise ValueError('Regenerate cache with the new pose-motion protocol')
                if not np.isclose(metadata.get('dt',-1),self.dt) or metadata.get('controlFrequencyInv')!=self.control_freq_inv:raise ValueError('Cache/time-step mismatch')
                if metadata.get('collisionConfigSha256')!=__import__('hashlib').sha256(open(self.config['env']['botyard']['collisionExcludes'],'rb').read()).hexdigest():raise ValueError('Cache/collision-mask mismatch')
                for key,value in [('objectMassKg',self.config['env']['object']['massKg']),('friction',self.config['env']['object']['fixedFriction'])]:
                    if not np.isclose(metadata.get(key,-1),value):raise ValueError('Cache/physical parameter mismatch: '+key)
                for key in ('pgain','dgain'):
                    if not np.isclose(metadata.get(key,-1),float(controller[key])):raise ValueError('Cache/controller gain mismatch: '+key)
                targets_t=to_torch(targets,device=self.device)
                if torch.any(targets_t<self.policy_dof_lower_limits-1e-6) or torch.any(targets_t>self.policy_dof_upper_limits+1e-6):
                    raise ValueError('Cached holding targets exceed URDF limits')
                states_t=to_torch(states,device=self.device)
                if torch.any(states_t[:,:20]<self.allegro_hand_dof_lower_limits-.01) or torch.any(states_t[:,:20]>self.allegro_hand_dof_upper_limits+.01):
                    raise ValueError('Cached actual joints exceed URDF limits')
                self.saved_grasping_states[str(scale)]=states_t
                self.cached_policy_targets[str(scale)]=targets_t

        self.rot_axis_buf = torch.zeros((self.num_envs, 3), device=self.device, dtype=torch.float)

        # useful buffers
        self.object_rot_prev = self.object_rot.clone()
        self.object_pos_prev = self.object_pos.clone()
        self.init_pose_buf = torch.zeros((self.num_envs, self.num_dofs), device=self.device, dtype=torch.float)
        self.holding_reference=torch.zeros_like(self.cur_policy_targets)
        self.object_position_reference=torch.zeros((self.num_envs,3),device=self.device)
        c=config['env']['constraints']
        self.target_offset_limits=to_torch(c['targetOffsetLimits16'],device=self.device)
        self.pose_normalizers=self.expand_policy_targets(self.target_offset_limits.unsqueeze(0))[0]
        self.pose_weights=to_torch(c['poseWeights20'],device=self.device)
        if len(c['targetOffsetLimits16'])!=16 or len(c['poseWeights20'])!=20 or torch.any(self.pose_normalizers<=0) or torch.any(self.pose_weights<=0):raise ValueError('Invalid constraint joint arrays')
        self.metric_counter=0
        self.actions = torch.zeros((self.num_envs, self.num_actions), device=self.device, dtype=torch.float)

        self.torques = torch.zeros(
            (self.num_envs, self.num_allegro_hand_dofs),
            device=self.device,
            dtype=torch.float
        )
        self.dof_vel_finite_diff = torch.zeros((self.num_envs, self.num_dofs), device=self.device, dtype=torch.float)
        assert type(self.p_gain) in [int, float] and type(self.d_gain) in [int, float], 'assume p_gain and d_gain are only scalars'
        self.p_gain = torch.ones(
            (self.num_envs, self.num_allegro_hand_dofs),
            device=self.device,
            dtype=torch.float
        ) * self.p_gain

        self.d_gain = torch.ones(
            (self.num_envs, self.num_allegro_hand_dofs),
            device=self.device,
            dtype=torch.float
        ) * self.d_gain

        # debug and understanding statistics
        self.env_timeout_counter = to_torch(np.zeros((len(self.envs)))).long().to(self.device)  # max 10 (10000 envs)
        self.stat_sum_rewards = 0
        self.stat_sum_rotate_rewards = 0
        self.stat_sum_episode_length = 0
        self.stat_sum_obj_linvel = 0
        self.stat_sum_torques = 0
        self.env_evaluated = 0
        self.max_evaluate_envs = 500000

    def _create_envs(self, num_envs, spacing, num_per_row):
        self._create_ground_plane()
        lower = gymapi.Vec3(-spacing, -spacing, 0.0)
        upper = gymapi.Vec3(spacing, spacing, spacing)

        self._create_object_asset()

        # set BotYard hand DOF properties
        self.num_allegro_hand_dofs = self.gym.get_asset_dof_count(self.hand_asset)
        allegro_hand_dof_props = self.gym.get_asset_dof_properties(self.hand_asset)

        # ------------------------------------------------------------------
        # Fixed-wrist BotYard model
        #
        # FAJ1 / FAJ3 must be URDF fixed joints, so they MUST NOT appear here
        # as simulator DOFs.  The remaining hand has:
        #   16 independent policy DOFs + 4 J1 mimic DOFs = 20 simulator DOFs.
        # Resolve every index by joint name instead of relying on raw numbers.
        # ------------------------------------------------------------------
        dof_names = list(self.gym.get_asset_dof_names(self.hand_asset))
        self.sim_dof_names=dof_names

        self.policy_joint_names = [
            'FFJ4', 'FFJ3', 'FFJ2',
            'LFJ4', 'LFJ3', 'LFJ2',
            'MFJ4', 'MFJ3', 'MFJ2',
            'RFJ4', 'RFJ3', 'RFJ2',
            'THJ4', 'THJ3', 'THJ2', 'THJ1',
        ]
        self.num_policy_dofs = len(self.policy_joint_names)

        expected_dofs = set(
            self.policy_joint_names
            + ['FFJ1', 'LFJ1', 'MFJ1', 'RFJ1']
        )

        if self.num_allegro_hand_dofs != 20:
            raise RuntimeError(
                'Fixed-wrist BotYard URDF must expose exactly 20 DOFs '
                f'(16 policy + 4 mimic), got {self.num_allegro_hand_dofs}. '
                f'Loaded DOFs: {dof_names}. '
                'Check that FAJ1 and FAJ3 are type="fixed" in the URDF.'
            )

        if set(dof_names) != expected_dofs:
            raise RuntimeError(
                'Unexpected fixed-wrist BotYard DOF names. '
                f'Loaded: {dof_names}; expected: {sorted(expected_dofs)}'
            )

        if 'FAJ1' in dof_names or 'FAJ3' in dof_names:
            raise RuntimeError(
                'FAJ1/FAJ3 are still simulator DOFs. '
                'They must be fixed joints in the URDF.'
            )

        self.policy_dof_indices = to_torch(
            [dof_names.index(n) for n in self.policy_joint_names],
            dtype=torch.long,
            device=self.device,
        )
        self.mimic_target_indices = to_torch(
            [dof_names.index(n) for n in ('FFJ1', 'LFJ1', 'MFJ1', 'RFJ1')],
            dtype=torch.long,
            device=self.device,
        )
        self.mimic_source_indices = to_torch(
            [dof_names.index(n) for n in ('FFJ2', 'LFJ2', 'MFJ2', 'RFJ2')],
            dtype=torch.long,
            device=self.device,
        )

        print('Fixed-wrist BotYard DOF count:', self.num_allegro_hand_dofs)
        print('Fixed-wrist BotYard DOF names:', dof_names)
        print(
            'BotYard policy DOF mapping:',
            dict(zip(self.policy_joint_names, self.policy_dof_indices.tolist()))
        )

        self.allegro_hand_dof_lower_limits = []
        self.allegro_hand_dof_upper_limits = []

        for i in range(self.num_allegro_hand_dofs):
            self.allegro_hand_dof_lower_limits.append(allegro_hand_dof_props['lower'][i])
            self.allegro_hand_dof_upper_limits.append(allegro_hand_dof_props['upper'][i])
            allegro_hand_dof_props['effort'][i] = 0.5
            if self.torque_control:
                allegro_hand_dof_props['stiffness'][i] = 0.
                allegro_hand_dof_props['damping'][i] = 0.
                allegro_hand_dof_props['driveMode'][i] = int(gymapi.DOF_MODE_EFFORT)
            else:
                allegro_hand_dof_props['stiffness'][i] = self.config['env']['controller']['pgain']
                allegro_hand_dof_props['damping'][i] = self.config['env']['controller']['dgain']
            allegro_hand_dof_props['friction'][i] = 0.0
            allegro_hand_dof_props['armature'][i] = 0.001

        self.allegro_hand_dof_lower_limits = to_torch(self.allegro_hand_dof_lower_limits, device=self.device)
        self.allegro_hand_dof_upper_limits = to_torch(self.allegro_hand_dof_upper_limits, device=self.device)

        hand_pose, obj_pose = self._init_object_pose()

        # compute aggregate size
        self.num_allegro_hand_bodies = self.gym.get_asset_rigid_body_count(self.hand_asset)
        self.num_allegro_hand_shapes = self.gym.get_asset_rigid_shape_count(self.hand_asset)
        max_agg_bodies = self.num_allegro_hand_bodies + 2
        max_agg_shapes = self.num_allegro_hand_shapes + 2

        self.envs = []

        self.object_init_state = []

        self.hand_indices = []
        self.object_indices = []

        allegro_hand_rb_count = self.gym.get_asset_rigid_body_count(self.hand_asset)
        object_rb_count = 1
        self.object_rb_handles = list(range(allegro_hand_rb_count, allegro_hand_rb_count + object_rb_count))

        for i in range(num_envs):
            # create env instance
            env_ptr = self.gym.create_env(self.sim, lower, upper, num_per_row)
            if self.aggregate_mode >= 1:
                self.gym.begin_aggregate(env_ptr, max_agg_bodies * 20, max_agg_shapes * 20, True)

            # Each scale keeps its own measured tilted hand root.
            hand_pose,obj_pose=self._seed_actor_poses(self.scale_seeds[str(float(self.env_scales_np[i]))])
            hand_actor = self.gym.create_actor(env_ptr, self.hand_asset, hand_pose, 'hand', i, 0, 0)
            import json
            with open(self.config['env']['botyard']['collisionExcludes']) as fh:
                collision_config=json.load(fh)
            apply_collision_masks(self.gym,env_ptr,hand_actor,collision_config)
            if i==0:
                self.finger_body_groups={}
                for finger in ('ff','lf','mf','rf','th'):
                    for segment in ('proximal','middle','distal'):
                        body=self.gym.find_actor_rigid_body_handle(env_ptr,hand_actor,finger+segment)
                        if body<0:raise RuntimeError('Unresolved finger contact body '+finger+segment)
                        self.finger_body_groups[body]=finger
                print('[COLLISION] named 28 exclusions applied; finger contact groups resolved',flush=True)
            self.gym.set_actor_dof_properties(env_ptr, hand_actor, allegro_hand_dof_props)
            hand_idx = self.gym.get_actor_index(env_ptr, hand_actor, gymapi.DOMAIN_SIM)
            self.hand_indices.append(hand_idx)

            # Resolve the five physical distal links by name instead of hard-coding indices.
            # These links carry the collision geometry used by PhysX contact queries.
            if i == 0:
                # Use distal links for physical contact detection.
                # The fixed *tip frames do not carry the collision geometry used by PhysX.
                fingertip_names = ['ffdistal', 'lfdistal', 'mfdistal', 'rfdistal', 'thdistal']
                self.fingertip_handles = [
                    self.gym.find_actor_rigid_body_handle(env_ptr, hand_actor, name)
                    for name in fingertip_names
                ]
                if any(handle < 0 for handle in self.fingertip_handles):
                    raise RuntimeError(
                        f'Failed to resolve BotYard fingertip handles: '
                        f'{dict(zip(fingertip_names, self.fingertip_handles))}'
                    )
                print('BotYard fingertip rigid-body handles:',
                      dict(zip(fingertip_names, self.fingertip_handles)))

            # add object
            object_type_id = np.random.choice(len(self.object_type_list), p=self.object_type_prob)
            object_asset = self.object_asset_list[object_type_id]

            object_handle = self.gym.create_actor(env_ptr, object_asset, obj_pose, 'object', i, 0, 0)

            # Store the object's environment-domain rigid-body handle.  This is
            # also resolved dynamically because hand body counts can change when
            # fixed joints are collapsed.
            if i == 0:
                self.object_body_handle = self.gym.get_actor_rigid_body_handle(
                    env_ptr, object_handle, 0
                )
                if self.object_body_handle < 0:
                    raise RuntimeError('Failed to resolve object rigid-body handle.')
                print('Object rigid-body handle:', self.object_body_handle)

            self.object_init_state.append([
                obj_pose.p.x, obj_pose.p.y, obj_pose.p.z,
                obj_pose.r.x, obj_pose.r.y, obj_pose.r.z, obj_pose.r.w,
                0, 0, 0, 0, 0, 0
            ])
            object_idx = self.gym.get_actor_index(env_ptr, object_handle, gymapi.DOMAIN_SIM)
            self.object_indices.append(object_idx)

            obj_scale = float(self.env_scales_np[i])
            self.gym.set_actor_scale(env_ptr, object_handle, obj_scale)
            self._update_priv_buf(env_id=i, name='obj_scale', value=obj_scale)

            obj_com = [0, 0, 0]
            if self.randomize_com:
                prop = self.gym.get_actor_rigid_body_properties(env_ptr, object_handle)
                assert len(prop) == 1
                obj_com = [np.random.uniform(self.randomize_com_lower, self.randomize_com_upper),
                           np.random.uniform(self.randomize_com_lower, self.randomize_com_upper),
                           np.random.uniform(self.randomize_com_lower, self.randomize_com_upper)]
                prop[0].com.x, prop[0].com.y, prop[0].com.z = obj_com
                self.gym.set_actor_rigid_body_properties(env_ptr, object_handle, prop)
            self._update_priv_buf(env_id=i, name='obj_com', value=obj_com)

            obj_friction = float(self.config['env']['object'].get('fixedFriction',1.0))
            for actor in (hand_actor,object_handle):
                fixed_props=self.gym.get_actor_rigid_shape_properties(env_ptr,actor)
                for prop in fixed_props:prop.friction=obj_friction;prop.restitution=0.
                self.gym.set_actor_rigid_shape_properties(env_ptr,actor,fixed_props)
            fixed_mass=self.config['env']['object'].get('massKg')
            if fixed_mass is not None:
                mass_props=self.gym.get_actor_rigid_body_properties(env_ptr,object_handle)
                for prop in mass_props:prop.mass=float(fixed_mass)
                self.gym.set_actor_rigid_body_properties(env_ptr,object_handle,mass_props,True)
            if self.randomize_friction:
                rand_friction = np.random.uniform(self.randomize_friction_lower, self.randomize_friction_upper)
                hand_props = self.gym.get_actor_rigid_shape_properties(env_ptr, hand_actor)
                for p in hand_props:
                    p.friction = rand_friction
                self.gym.set_actor_rigid_shape_properties(env_ptr, hand_actor, hand_props)

                object_props = self.gym.get_actor_rigid_shape_properties(env_ptr, object_handle)
                for p in object_props:
                    p.friction = rand_friction
                self.gym.set_actor_rigid_shape_properties(env_ptr, object_handle, object_props)
                obj_friction = rand_friction
            self._update_priv_buf(env_id=i, name='obj_friction', value=obj_friction)

            if self.randomize_mass:
                prop = self.gym.get_actor_rigid_body_properties(env_ptr, object_handle)
                for p in prop:
                    p.mass = np.random.uniform(self.randomize_mass_lower, self.randomize_mass_upper)
                self.gym.set_actor_rigid_body_properties(env_ptr, object_handle, prop)
                self._update_priv_buf(env_id=i, name='obj_mass', value=prop[0].mass)
            else:
                prop = self.gym.get_actor_rigid_body_properties(env_ptr, object_handle)
                self._update_priv_buf(env_id=i, name='obj_mass', value=prop[0].mass)

            if self.aggregate_mode > 0:
                self.gym.end_aggregate(env_ptr)

            self.envs.append(env_ptr)

        self.object_init_state = to_torch(self.object_init_state, device=self.device, dtype=torch.float).view(self.num_envs, 13)
        self.object_rb_handles = to_torch(self.object_rb_handles, dtype=torch.long, device=self.device)
        self.hand_indices = to_torch(self.hand_indices, dtype=torch.long, device=self.device)
        self.object_indices = to_torch(self.object_indices, dtype=torch.long, device=self.device)

    def reset_idx(self, env_ids):
        if self.randomize_pd_gains:
            self.p_gain[env_ids] = torch_rand_float(
                self.randomize_p_gain_lower, self.randomize_p_gain_upper, (len(env_ids), self.num_allegro_hand_dofs),
                device=self.device).squeeze(1)
            self.d_gain[env_ids] = torch_rand_float(
                self.randomize_d_gain_lower, self.randomize_d_gain_upper, (len(env_ids), self.num_allegro_hand_dofs),
                device=self.device).squeeze(1)

        # reset rigid body forces
        self.rb_forces[env_ids, :, :] = 0.0

        num_scales = len(self.randomize_scale_list)
        for n_s in range(num_scales):
            s_ids = env_ids[(env_ids % num_scales == n_s).nonzero(as_tuple=False).squeeze(-1)]
            if len(s_ids) == 0:
                continue
            obj_scale = self.randomize_scale_list[n_s]
            scale_key = str(obj_scale)
            sampled_pose_idx = np.random.randint(self.saved_grasping_states[scale_key].shape[0], size=len(s_ids))
            sampled_pose = \
                self.saved_grasping_states[
                    scale_key
                ][sampled_pose_idx].clone()

            # ------------------------------------
            # New BotYard grasp-cache layout:
            #
            # [0:20]  fixed-wrist BotYard hand DOF position
            # [20:27]  object pose (xyz + quaternion xyzw)
            # ------------------------------------

            hand_pose = sampled_pose[
                :, :self.num_allegro_hand_dofs
            ]

            object_pose = sampled_pose[
                :,
                self.num_allegro_hand_dofs:
                self.num_allegro_hand_dofs + 7
            ].clone()
            object_pose[:,:3]+=self.state_offsets[s_ids]

            self.root_state_tensor[
                self.object_indices[s_ids], :7
            ] = object_pose

            self.root_state_tensor[
                self.object_indices[s_ids], 7:13
            ] = 0

            # Actual joint state and its OWN sampled holding target are distinct.
            # Never substitute one global canonical target for a multi-seed cache.
            # Exact physical state comes from cache.
            self.allegro_hand_dof_pos[
                s_ids, :
            ] = hand_pose

            self.allegro_hand_dof_vel[
                s_ids, :
            ] = 0

            # Restore the 16-D grasping target, NOT the cached actual state.
            policy_target = self.cached_policy_targets[scale_key][sampled_pose_idx].clone()
            self.holding_reference[s_ids]=policy_target
            self.object_position_reference[s_ids]=object_pose[:,:3]

            full_target = self.expand_policy_targets(
                policy_target
            )

            self.prev_policy_targets[
                s_ids, :
            ] = policy_target

            self.cur_policy_targets[
                s_ids, :
            ] = policy_target

            self.prev_targets[
                s_ids, :self.num_allegro_hand_dofs
            ] = full_target

            self.cur_targets[
                s_ids, :self.num_allegro_hand_dofs
            ] = full_target

            # Reward reference remains the exact restored physical state.
            self.init_pose_buf[
                s_ids, :self.num_allegro_hand_dofs
            ] = hand_pose.clone()


        object_indices = torch.unique(self.object_indices[env_ids]).to(torch.int32)
        self.gym.set_actor_root_state_tensor_indexed(self.sim, gymtorch.unwrap_tensor(self.root_state_tensor), gymtorch.unwrap_tensor(object_indices), len(object_indices))
        hand_indices = self.hand_indices[env_ids].to(torch.int32)
        if not self.torque_control:
            self.gym.set_dof_position_target_tensor_indexed(self.sim, gymtorch.unwrap_tensor(self.prev_targets), gymtorch.unwrap_tensor(hand_indices), len(env_ids))
        self.gym.set_dof_state_tensor_indexed(self.sim, gymtorch.unwrap_tensor(self.dof_state), gymtorch.unwrap_tensor(hand_indices), len(env_ids))

        self.progress_buf[env_ids] = 0
        self.obs_buf[env_ids] = 0
        self.rb_forces[env_ids] = 0
        self.priv_info_buf[env_ids, 0:3] = 0
        self.proprio_hist_buf[env_ids] = 0
        self.at_reset_buf[env_ids] = 1

    def compute_observations(self):
        self._refresh_gym()

        # --------------------------------------------
        # Only expose the 16 independent policy DOFs
        # --------------------------------------------
        policy_dof_pos = \
            self.allegro_hand_dof_pos[:, self.policy_dof_indices]

        prev_obs_buf = \
            self.obs_buf_lag_history[:, 1:].clone()

        # noise must also be [N,16]
        joint_noise_matrix = (
            torch.rand_like(policy_dof_pos) * 2.0 - 1.0
        ) * self.joint_noise_scale

        # normalized 16 joint positions
        cur_obs_buf = unscale(
            joint_noise_matrix + policy_dof_pos,
            self.policy_dof_lower_limits,
            self.policy_dof_upper_limits
        ).clone().unsqueeze(1)

        # 16 policy targets
        cur_tar_buf = \
            self.cur_policy_targets.unsqueeze(1)

        # 16 + 16 = 32
        cur_obs_buf = torch.cat(
            [cur_obs_buf, cur_tar_buf],
            dim=-1
        )

        self.obs_buf_lag_history[:] = torch.cat(
            [prev_obs_buf, cur_obs_buf],
            dim=1
        )

        # --------------------------------------------
        # Initialize observation history after reset
        # --------------------------------------------
        at_reset_env_ids = \
            self.at_reset_buf.nonzero(
                as_tuple=False
            ).squeeze(-1)

        if len(at_reset_env_ids) > 0:
            reset_policy_pos = policy_dof_pos[
                at_reset_env_ids
            ]

            reset_policy_pos_norm = unscale(
                reset_policy_pos,
                self.policy_dof_lower_limits,
                self.policy_dof_upper_limits
            )

            self.obs_buf_lag_history[
                at_reset_env_ids, :, 0:16
            ] = reset_policy_pos_norm.unsqueeze(1)

            self.obs_buf_lag_history[
                at_reset_env_ids, :, 16:32
            ] = self.cur_policy_targets[
                at_reset_env_ids
            ].unsqueeze(1)

        # Stage 1 uses the latest 3 frames:
        # 3 x 32 = 96
        t_buf = (
            self.obs_buf_lag_history[:, -3:]
            .reshape(self.num_envs, -1)
        ).clone()

        self.obs_buf[:, :t_buf.shape[1]] = t_buf

        self.at_reset_buf[at_reset_env_ids] = 0

        # Stage 2 history
        self.proprio_hist_buf[:] = \
            self.obs_buf_lag_history[
                :, -self.prop_hist_len:
            ].clone()

        self._update_priv_buf(
            env_id=range(self.num_envs),
            name='obj_position',
            value=(self.object_pos-self.state_offsets).clone()
        )


    def compute_reward(self, actions):
        self.rot_axis_buf[:, -1] = -1
        # pose diff penalty
        
        if self.hora_baseline:
            pose_diff_penalty = ((self.allegro_hand_dof_pos-self.init_pose_buf)**2).sum(-1)
        else:
            pose_diff_penalty = (self.pose_weights*((self.allegro_hand_dof_pos-self.init_pose_buf)/self.pose_normalizers)**2).sum(-1)/self.pose_weights.sum()
        # work and torque penalty
        torque_penalty = (self.torques ** 2).sum(-1)
        work_penalty = ((self.torques * self.dof_vel_finite_diff).sum(-1)) ** 2
        # Compute offset in radians. Radians -> radians / sec
        relative_rotation=quat_mul(self.object_rot,quat_conjugate(self.object_rot_prev))
        relative_rotation=torch.where(relative_rotation[:,3:4]<0,-relative_rotation,relative_rotation)
        angdiff = quat_to_axis_angle(relative_rotation)
        object_angvel = angdiff / (self.control_freq_inv * self.dt)
        if self.hora_baseline:object_angvel=self.object_angvel
        vec_dot = (object_angvel * self.rot_axis_buf).sum(-1)
        rotate_reward = torch.clip(vec_dot, max=self.angvel_clip_max, min=self.angvel_clip_min)
        # linear velocity: use position difference instead of self.object_linvel
        object_linvel = ((self.object_pos - self.object_pos_prev) / (self.control_freq_inv * self.dt)).clone()
        if self.hora_baseline:
            object_linvel_penalty=torch.norm(self.object_linvel,p=1,dim=-1)
        else:
            object_linvel_penalty = torch.clamp(torch.norm(object_linvel,p=1,dim=-1)/.05,max=5.)
        delta=self.object_pos-self.object_position_reference
        position_penalty=torch.clamp(((delta/.01)**2).sum(-1),max=25.)
        axis_z=1-2*(self.object_rot[:,0]**2+self.object_rot[:,1]**2)
        tilt=torch.acos(torch.clamp(axis_z.abs(),0,1))
        tilt_penalty=torch.clamp((tilt/np.deg2rad(5.))**2,max=25.)

        self.rew_buf[:] = compute_hand_reward(
            object_linvel_penalty, self.object_linvel_penalty_scale,
            rotate_reward, self.rotate_reward_scale,
            pose_diff_penalty, self.pose_diff_penalty_scale,
            torque_penalty, self.torque_penalty_scale,
            work_penalty, self.work_penalty_scale,
        )
        c=self.config['env']['constraints']
        bad_drift=torch.linalg.norm(delta[:,:2],dim=1)>float(c['maxHorizontalDriftM'])
        bad_drop=delta[:,2]<-float(c['maxDropM'])
        bad_height=delta[:,2].abs()>float(c['maxVerticalDriftM'])
        bad_tilt=tilt>np.deg2rad(float(c['maxTiltDeg']))
        bad_pose=torch.any(torch.abs(self.allegro_hand_dof_pos-self.init_pose_buf)>float(c['maxActualPoseOffsetMultiplier'])*self.pose_normalizers,dim=1)
        failure=bad_drift|bad_drop|bad_height|bad_tilt|bad_pose
        if self.hora_baseline:
            # The original task terminates on object height or episode length.
            # Cache object positions are environment-local, including z.
            failure=(self.object_pos-self.state_offsets)[:,2]<self.reset_z_threshold
            self.reset_buf[:]=self.check_termination(self.object_pos-self.state_offsets).long()
        else:
            self.rew_buf[:]+=float(c['positionPenaltyScale'])*position_penalty+float(c['tiltPenaltyScale'])*tilt_penalty
            self.rew_buf[:]+=failure.float()*float(c['failurePenalty'])
            self.reset_buf[:]=(failure|(self.progress_buf>=self.max_episode_length)).long()
        self.extras['position_error_m']=torch.linalg.norm(delta,dim=1).mean()
        self.extras['tilt_deg']=torch.rad2deg(tilt).mean()
        self.extras['position_penalty']=position_penalty.mean()
        self.extras['tilt_penalty']=tilt_penalty.mean()
        self.extras['target_boundary_fraction']=((self.cur_policy_targets-self.holding_reference).abs()>=self.target_offset_limits-1e-6).float().mean()
        self.metric_counter+=1
        interval=int(self.config['env'].get('debugMetricsEvery',100))
        if interval>0 and self.metric_counter%interval==0:
            self._write_constraint_metrics(delta,tilt,pose_diff_penalty,position_penalty,tilt_penalty,object_linvel_penalty,rotate_reward,failure)
        self.extras['rotation_reward'] = rotate_reward.mean()
        self.extras['object_linvel_penalty'] = object_linvel_penalty.mean()
        self.extras['pose_diff_penalty'] = pose_diff_penalty.mean()
        self.extras['work_done'] = work_penalty.mean()
        self.extras['torques'] = torque_penalty.mean()
        self.extras['roll'] = object_angvel[:, 0].mean()
        self.extras['pitch'] = object_angvel[:, 1].mean()
        self.extras['yaw'] = object_angvel[:, 2].mean()

        if self.evaluate:
            finished_episode_mask = self.reset_buf == 1
            self.stat_sum_rewards += self.rew_buf.sum()
            self.stat_sum_rotate_rewards += rotate_reward.sum()
            self.stat_sum_torques += self.torques.abs().sum()
            self.stat_sum_obj_linvel += (self.object_linvel ** 2).sum(-1).sum()
            self.stat_sum_episode_length += (self.reset_buf == 0).sum()
            self.env_evaluated += (self.reset_buf == 1).sum()
            self.env_timeout_counter[finished_episode_mask] += 1
            info = f'progress {self.env_evaluated} / {self.max_evaluate_envs} | ' \
                   f'reward: {self.stat_sum_rewards / self.env_evaluated:.2f} | ' \
                   f'eps length: {self.stat_sum_episode_length / self.env_evaluated:.2f} | ' \
                   f'rotate reward: {self.stat_sum_rotate_rewards / self.env_evaluated:.2f} | ' \
                   f'lin vel (x100): {self.stat_sum_obj_linvel * 100 / self.stat_sum_episode_length:.4f} | ' \
                   f'command torque: {self.stat_sum_torques / self.stat_sum_episode_length:.2f}'
            tprint(info)
            if self.env_evaluated >= self.max_evaluate_envs:
                exit()

    def post_physics_step(self):
        self.progress_buf += 1
        self.reset_buf[:] = 0
        self._refresh_gym()
        self.compute_reward(self.actions)
        env_ids = self.reset_buf.nonzero(as_tuple=False).squeeze(-1)
        if len(env_ids) > 0:
            self.reset_idx(env_ids)
        self.compute_observations()

        if self.viewer and self.debug_viz:
            # draw axes on target object
            self.gym.clear_lines(self.viewer)
            self.gym.refresh_rigid_body_state_tensor(self.sim)

            for i in range(self.num_envs):
                objectx = (self.object_pos[i] + quat_apply(self.object_rot[i], to_torch([1, 0, 0], device=self.device) * 0.2)).cpu().numpy()
                objecty = (self.object_pos[i] + quat_apply(self.object_rot[i], to_torch([0, 1, 0], device=self.device) * 0.2)).cpu().numpy()
                objectz = (self.object_pos[i] + quat_apply(self.object_rot[i], to_torch([0, 0, 1], device=self.device) * 0.2)).cpu().numpy()

                p0 = self.object_pos[i].cpu().numpy()
                self.gym.add_lines(self.viewer, self.envs[i], 1, [p0[0], p0[1], p0[2], objectx[0], objectx[1], objectx[2]], [0.85, 0.1, 0.1])
                self.gym.add_lines(self.viewer, self.envs[i], 1, [p0[0], p0[1], p0[2], objecty[0], objecty[1], objecty[2]], [0.1, 0.85, 0.1])
                self.gym.add_lines(self.viewer, self.envs[i], 1, [p0[0], p0[1], p0[2], objectz[0], objectz[1], objectz[2]], [0.1, 0.1, 0.85])

    def _create_ground_plane(self):
        plane_params = gymapi.PlaneParams()
        plane_params.normal = gymapi.Vec3(0.0, 0.0, 1.0)
        self.gym.add_ground(self.sim, plane_params)

    def expand_policy_targets(self, policy_targets):
        """Expand 16 policy targets to the 20 movable BotYard hand DOFs.

        FAJ1 and FAJ3 are not present here: they are true fixed joints in the
        URDF and therefore are not simulator DOFs.

        Four J1 joints follow their corresponding J2 targets:
            FFJ1 <- FFJ2
            LFJ1 <- LFJ2
            MFJ1 <- MFJ2
            RFJ1 <- RFJ2
        """
        if policy_targets.shape[-1] != self.num_policy_dofs:
            raise ValueError(
                f'Expected {self.num_policy_dofs} policy targets, '
                f'got shape {tuple(policy_targets.shape)}'
            )

        full_targets = torch.zeros(
            (policy_targets.shape[0], self.num_allegro_hand_dofs),
            dtype=policy_targets.dtype,
            device=policy_targets.device
        )

        full_targets[:, self.policy_dof_indices] = policy_targets
        full_targets[:, self.mimic_target_indices] = \
            full_targets[:, self.mimic_source_indices]

        return full_targets

    def pre_physics_step(self, actions):
        self.actions = actions.clone().to(self.device)

        # ------------------------------------------------
        # 1. HORA policy operates in the 16-D policy space
        # ------------------------------------------------
        policy_targets = (
            self.prev_policy_targets
            + (1./24 if self.hora_baseline else float(self.config['env']['controller']['actionStepRad'])) * self.actions
        )

        # Clamp using the limits of the 16 independent DOFs
        self.cur_policy_targets[:] = tensor_clamp(
            policy_targets,
            self.policy_dof_lower_limits if self.hora_baseline else torch.maximum(self.policy_dof_lower_limits,self.holding_reference-self.target_offset_limits),
            self.policy_dof_upper_limits if self.hora_baseline else torch.minimum(self.policy_dof_upper_limits,self.holding_reference+self.target_offset_limits)
        )

        self.prev_policy_targets[:] = \
            self.cur_policy_targets.clone()

        # ------------------------------------------------
        # 2. Expand 16-D targets to 20-D fixed-wrist BotYard targets
        # ------------------------------------------------
        full_targets = self.expand_policy_targets(
            self.cur_policy_targets
        )

        self.cur_targets[:, :self.num_allegro_hand_dofs] = \
            full_targets

        self.prev_targets[:, :self.num_allegro_hand_dofs] = \
            full_targets

        # ------------------------------------------------
        # 3. Save object state for reward calculation
        # ------------------------------------------------
        self.object_rot_prev[:] = self.object_rot
        self.object_pos_prev[:] = self.object_pos

        # ------------------------------------------------
        # 4. Keep original random external force logic
        # ------------------------------------------------
        if self.force_scale > 0.0:
            self.rb_forces *= torch.pow(
                self.force_decay,
                self.dt / self.force_decay_interval
            )

            obj_mass = to_torch(
                [
                    self.gym.get_actor_rigid_body_properties(
                        env,
                        self.gym.find_actor_handle(env, 'object')
                    )[0].mass
                    for env in self.envs
                ],
                device=self.device
            )

            prob = self.random_force_prob_scalar

            force_indices = (
                torch.less(
                    torch.rand(self.num_envs, device=self.device),
                    prob
                )
            ).nonzero()

            self.rb_forces[
                force_indices,
                self.object_rb_handles,
                :
            ] = (
                torch.randn(
                    self.rb_forces[
                        force_indices,
                        self.object_rb_handles,
                        :
                    ].shape,
                    device=self.device
                )
                * obj_mass[force_indices, None]
                * self.force_scale
            )

            self.gym.apply_rigid_body_force_tensors(
                self.sim,
                gymtorch.unwrap_tensor(self.rb_forces),
                None,
                gymapi.ENV_SPACE
            )


    def reset(self):
        super().reset()
        self.obs_dict['priv_info'] = self.priv_info_buf.to(self.rl_device)
        self.obs_dict['proprio_hist'] = self.proprio_hist_buf.to(self.rl_device)
        return self.obs_dict

    def step(self, actions):
        super().step(actions)
        self.obs_dict['priv_info'] = self.priv_info_buf.to(self.rl_device)
        self.obs_dict['proprio_hist'] = self.proprio_hist_buf.to(self.rl_device)
        return self.obs_dict, self.rew_buf.to(self.rl_device), self.reset_buf.to(self.rl_device), self.extras

    def update_low_level_control(self):
        self._refresh_gym()
        if self.torque_control:
            dof_pos = self.allegro_hand_dof_pos
            # The measured simulator velocity includes motion during the latest
            # physical step. Differencing two identical refreshed CPU buffers
            # had silently removed damping in the previous implementation.
            dof_vel = self.allegro_hand_dof_vel
            self.dof_vel_finite_diff = dof_vel.clone()
            torques = self.p_gain * (self.cur_targets - dof_pos) - self.d_gain * dof_vel
            self.torques = torch.clip(torques, -0.5, 0.5).clone()
            self.gym.set_dof_actuation_force_tensor(self.sim, gymtorch.unwrap_tensor(self.torques))
        else:
            self.gym.set_dof_position_target_tensor(self.sim, gymtorch.unwrap_tensor(self.cur_targets))

    def on_physics_step(self):
        observer=getattr(self, "physics_observer", None)
        if observer is not None: observer(self)

    def check_termination(self, object_pos):
        resets = torch.logical_or(
            torch.less(object_pos[:, -1], self.reset_z_threshold),
            torch.greater_equal(self.progress_buf, self.max_episode_length),
        )
        return resets

    def _refresh_gym(self):
        self.gym.refresh_dof_state_tensor(self.sim)
        self.gym.refresh_actor_root_state_tensor(self.sim)
        self.gym.refresh_rigid_body_state_tensor(self.sim)
        self.gym.refresh_net_contact_force_tensor(self.sim)
        self.object_pose = self.root_state_tensor[self.object_indices, 0:7]
        self.object_pos = self.root_state_tensor[self.object_indices, 0:3]
        self.object_rot = self.root_state_tensor[self.object_indices, 3:7]
        self.object_linvel = self.root_state_tensor[self.object_indices, 7:10]
        self.object_angvel = self.root_state_tensor[self.object_indices, 10:13]

    def _setup_domain_rand_config(self, rand_config):
        self.randomize_mass = rand_config['randomizeMass']
        self.randomize_mass_lower = rand_config['randomizeMassLower']
        self.randomize_mass_upper = rand_config['randomizeMassUpper']
        self.randomize_com = rand_config['randomizeCOM']
        self.randomize_com_lower = rand_config['randomizeCOMLower']
        self.randomize_com_upper = rand_config['randomizeCOMUpper']
        self.randomize_friction = rand_config['randomizeFriction']
        self.randomize_friction_lower = rand_config['randomizeFrictionLower']
        self.randomize_friction_upper = rand_config['randomizeFrictionUpper']
        self.randomize_scale = rand_config['randomizeScale']
        self.scale_list_init = rand_config['scaleListInit']
        self.randomize_scale_list = rand_config['randomizeScaleList']
        self.randomize_scale_lower = rand_config['randomizeScaleLower']
        self.randomize_scale_upper = rand_config['randomizeScaleUpper']
        self.randomize_pd_gains = rand_config['randomizePDGains']
        self.randomize_p_gain_lower = rand_config['randomizePGainLower']
        self.randomize_p_gain_upper = rand_config['randomizePGainUpper']
        self.randomize_d_gain_lower = rand_config['randomizeDGainLower']
        self.randomize_d_gain_upper = rand_config['randomizeDGainUpper']
        self.joint_noise_scale = rand_config['jointNoiseScale']

    def _setup_priv_option_config(self, p_config):
        self.enable_priv_obj_position = p_config['enableObjPos']
        self.enable_priv_obj_mass = p_config['enableObjMass']
        self.enable_priv_obj_scale = p_config['enableObjScale']
        self.enable_priv_obj_com = p_config['enableObjCOM']
        self.enable_priv_obj_friction = p_config['enableObjFriction']

    def _update_priv_buf(self, env_id, name, value, lower=None, upper=None):
        # normalize to -1, 1
        s, e = self.priv_info_dict[name]
        if eval(f'self.enable_priv_{name}'):
            if type(value) is list:
                value = to_torch(value, dtype=torch.float, device=self.device)
            if type(lower) is list or upper is list:
                lower = to_torch(lower, dtype=torch.float, device=self.device)
                upper = to_torch(upper, dtype=torch.float, device=self.device)
            if lower is not None and upper is not None:
                value = (2.0 * value - upper - lower) / (upper - lower)
            self.priv_info_buf[env_id, s:e] = value
        else:
            self.priv_info_buf[env_id, s:e] = 0

    def _setup_object_info(self, o_config):
        if o_config.get('assetFile'):
            self.object_type='single';self.object_type_list=['single'];self.object_type_prob=[1.]
            self.asset_files_dict={'single':o_config['assetFile']}
            return
        self.object_type = o_config['type']
        raw_prob = o_config['sampleProb']
        assert (sum(raw_prob) == 1)

        primitive_list = self.object_type.split('+')
        print('---- Primitive List ----')
        print(primitive_list)
        self.object_type_prob = []
        self.object_type_list = []
        self.asset_files_dict = {
            'simple_tennis_ball': 'assets/ball.urdf',
        }
        for p_id, prim in enumerate(primitive_list):
            if 'cuboid' in prim:
                subset_name = self.object_type.split('_')[-1]
                cuboids = sorted(glob(f'../assets/cuboid/{subset_name}/*.urdf'))
                cuboid_list = [f'cuboid_{i}' for i in range(len(cuboids))]
                self.object_type_list += cuboid_list
                for i, name in enumerate(cuboids):
                    self.asset_files_dict[f'cuboid_{i}'] = name.replace('../assets/', '')
                self.object_type_prob += [raw_prob[p_id] / len(cuboid_list) for _ in cuboid_list]
            elif 'cylinder' in prim:
                subset_name = self.object_type.split('_')[-1]
                cylinders = sorted(glob(f'assets/cylinder/{subset_name}/*.urdf'))
                cylinder_list = [f'cylinder_{i}' for i in range(len(cylinders))]
                self.object_type_list += cylinder_list
                for i, name in enumerate(cylinders):
                    self.asset_files_dict[f'cylinder_{i}'] = name.replace('../assets/', '')
                self.object_type_prob += [raw_prob[p_id] / len(cylinder_list) for _ in cylinder_list]
            else:
                self.object_type_list += [prim]
                self.object_type_prob += [raw_prob[p_id]]
        print('---- Object List ----')
        print(self.object_type_list)
        assert (len(self.object_type_list) == len(self.object_type_prob))

    def _allocate_task_buffer(self, num_envs):
        # extra buffers for observe randomized params
        self.prop_hist_len = self.config['env']['hora']['propHistoryLen']
        self.num_env_factors = self.config['env']['hora']['privInfoDim']
        self.priv_info_buf = torch.zeros((num_envs, self.num_env_factors), device=self.device, dtype=torch.float)
        self.proprio_hist_buf = torch.zeros((num_envs, self.prop_hist_len, 32), device=self.device, dtype=torch.float)

    def _setup_reward_config(self, r_config):
        self.angvel_clip_min = r_config['angvelClipMin']
        self.angvel_clip_max = r_config['angvelClipMax']
        self.rotate_reward_scale = r_config['rotateRewardScale']
        self.object_linvel_penalty_scale = r_config['objLinvelPenaltyScale']
        self.pose_diff_penalty_scale = r_config['poseDiffPenaltyScale']
        self.torque_penalty_scale = r_config['torquePenaltyScale']
        self.work_penalty_scale = r_config['workPenaltyScale']

    def _create_object_asset(self):
        # object file to asset
        asset_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../')
        hand_asset_file = self.config['env']['asset']['handAsset']
        # load hand asset
        hand_asset_options = gymapi.AssetOptions()
        hand_asset_options.flip_visual_attachments = False
        hand_asset_options.fix_base_link = True
        hand_asset_options.collapse_fixed_joints = False
        hand_asset_options.disable_gravity = True
        hand_asset_options.use_physx_armature = True

        if self.torque_control:
            hand_asset_options.default_dof_drive_mode = int(gymapi.DOF_MODE_EFFORT)
        else:
            hand_asset_options.default_dof_drive_mode = gymapi.DOF_MODE_POS
        self.hand_asset = self.gym.load_asset(self.sim, asset_root, hand_asset_file, hand_asset_options)

        # load object asset
        self.object_asset_list = []
        for object_type in self.object_type_list:
            object_asset_file = self.asset_files_dict[object_type]
            object_asset_options = gymapi.AssetOptions()
            object_asset = self.gym.load_asset(self.sim, asset_root, object_asset_file, object_asset_options)
            self.object_asset_list.append(object_asset)

    def _seed_actor_poses(self, seed):
        poses=[]
        for values in (seed['handRoot7'],seed['object7']):
            pose=gymapi.Transform();pose.p=gymapi.Vec3(*map(float,values[:3]));pose.r=gymapi.Quat(*map(float,values[3:]))
            poses.append(pose)
        return tuple(poses)

    def _init_object_pose(self):
        return self._seed_actor_poses(self.scale_seeds[str(float(self.env_scales_np[0]))])

    def _write_constraint_metrics(self, delta, tilt, shape, position, tilt_penalty, velocity, rotation, failure):
        import json
        from pathlib import Path
        c=self.config['env']['constraints'];r=self.config['env']['reward']
        groups={}
        for scale in self.randomize_scale_list:
            mask=self.env_scales==float(scale)
            if not torch.any(mask):continue
            groups[str(float(scale))]=dict(positionErrorMm=float(torch.linalg.norm(delta[mask],dim=1).mean()*1000),
                maxPositionErrorMm=float(torch.linalg.norm(delta[mask],dim=1).max()*1000),tiltDeg=float(torch.rad2deg(tilt[mask]).mean()),
                weightedShape=float(shape[mask].mean()*float(r['poseDiffPenaltyScale'])),
                weightedPosition=0. if self.hora_baseline else float(position[mask].mean()*float(c['positionPenaltyScale'])),
                weightedTilt=0. if self.hora_baseline else float(tilt_penalty[mask].mean()*float(c['tiltPenaltyScale'])),
                weightedLinearVelocity=float(velocity[mask].mean()*float(r['objLinvelPenaltyScale'])),
                rotationReward=float(rotation[mask].mean()*float(r['rotateRewardScale'])),failedEnvs=int(failure[mask].sum()))
        entry=dict(controlStep=self.metric_counter,scales=groups)
        # Include one representative state so visual oddities can be inspected.
        entry['env0']=dict(q20=self.allegro_hand_dof_pos[0].cpu().numpy().tolist(),
            target16=self.cur_policy_targets[0].cpu().numpy().tolist(),referenceQ20=self.init_pose_buf[0].cpu().numpy().tolist(),
            referenceTarget16=self.holding_reference[0].cpu().numpy().tolist(),
            referencePosition=self.object_position_reference[0].cpu().numpy().tolist(),object7=self.object_pose[0].cpu().numpy().tolist())
        print('[METRICS]',json.dumps(dict(controlStep=entry['controlStep'],scales=groups)),flush=True)
        path=self.config['env'].get('metricsPath','')
        if path:
            destination=Path(path);destination.parent.mkdir(parents=True,exist_ok=True)
            with destination.open('a') as f:f.write(json.dumps(entry)+'\n')



def compute_hand_reward(
    object_linvel_penalty, object_linvel_penalty_scale: float,
    rotate_reward, rotate_reward_scale: float,
    pose_diff_penalty, pose_diff_penalty_scale: float,
    torque_penalty, torque_pscale: float,
    work_penalty, work_pscale: float,
):
    reward = rotate_reward_scale * rotate_reward
    # Distance from the hand to the object
    reward = reward + object_linvel_penalty * object_linvel_penalty_scale
    reward = reward + pose_diff_penalty * pose_diff_penalty_scale
    reward = reward + torque_penalty * torque_pscale
    reward = reward + work_penalty * work_pscale
    return reward


def quat_to_axis_angle(quaternions: torch.Tensor) -> torch.Tensor:
    """
    Convert rotations given as quaternions to axis/angle.
    Adapted from PyTorch3D:
    https://pytorch3d.readthedocs.io/en/latest/_modules/pytorch3d/transforms/rotation_conversions.html#quaternion_to_axis_angle
    Args:
        quaternions: quaternions with real part last,
            as tensor of shape (..., 4).
    Returns:
        Rotations given as a vector in axis angle form, as a tensor
            of shape (..., 3), where the magnitude is the angle
            turned anticlockwise in radians around the vector's
            direction.
    """
    norms = torch.norm(quaternions[..., :3], p=2, dim=-1, keepdim=True)
    half_angles = torch.atan2(norms, quaternions[..., 3:])
    angles = 2 * half_angles
    eps = 1e-6
    small_angles = angles.abs() < eps
    sin_half_angles_over_angles = torch.empty_like(angles)
    sin_half_angles_over_angles[~small_angles] = (
        torch.sin(half_angles[~small_angles]) / angles[~small_angles]
    )
    # for x small, sin(x/2) is about x/2 - (x/2)^3/6
    # so sin(x/2)/x is about 1/2 - (x*x)/48
    sin_half_angles_over_angles[small_angles] = (
        0.5 - (angles[small_angles] * angles[small_angles]) / 48
    )
    return quaternions[..., :3] / sin_half_angles_over_angles
